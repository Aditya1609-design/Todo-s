export default function App() {
  return (
    <div>
      <h2 className="font-semibold text-red-500">
        Hello from React with Tailwind
      </h2>
    </div>
  );
}
